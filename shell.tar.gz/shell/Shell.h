#ifndef SHELL_H
#define SHELL_H

#include <string>
#include <vector>
#include <set>
#include <map>

class Shell {
public:
    Shell();
    void run();
    void executeCommand(const std::string& line);
    void defineFunction(const std::string& functionName, const std::vector<std::string>& functionBody);
    void executeSimpleCommand(const std::vector<std::string>& tokens);
    void executeWithPipe(const std::vector<std::string>& tokens, size_t pipe_pos);

    void prepareArgsAndRedirects(const std::vector<std::string>& tokens,
                                  std::vector<char*>& args,
                                  bool& input_redirect, std::string& input_file,
                                  bool& output_redirect, bool& append_redirect, std::string& output_file);
    void performRedirects(bool input_redirect, const std::string& input_file,
                           bool output_redirect, bool append_redirect, const std::string& output_file);
    void executeCommandWithArgs(std::vector<char*>& args);
    std::vector<std::string> tokenize(const std::string& line);

    std::map<std::string, std::string> environment; // 假设存在环境变量映射
private:
    std::string prompt;
    std::string replaceVariables(const std::string& line);
    std::map<std::string, std::vector<std::string>> functions;
    void executeIf(const std::vector<std::string>& tokens);
    void executeWhile(const std::vector<std::string>& tokens);
    void executeFor(const std::vector<std::string>& tokens);
    void executeFunction(const std::vector<std::string>& tokens);
    bool isControlStatement(const std::string& command);
    bool evaluateCondition(const std::vector<std::string>& conditionTokens);
};

#endif // SHELL_H
