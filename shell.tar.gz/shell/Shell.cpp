#include "Shell.h"
#include <iostream>
#include <cstdio>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <cstdlib>
#include <cstring>
#include <sstream>

// Shell 类的实现

// 构造函数
Shell::Shell() : prompt("myshell> ") {
    // 构造函数的实现
}

// 运行 Shell 循环
// Shell 类的运行循环
void Shell::run() {
    const size_t max_input_length = 4096; // 定义最大输入长度
    std::string line;
    while (true) {
        std::cout << prompt;
        if (!std::getline(std::cin, line)) {
            break; // Exit loop on EOF or other input error
        }
        // 检查输入长度是否超出限制
        if (line.length() > max_input_length) {
            std::cerr << "Error: Input exceeds maximum allowed length." << std::endl;
            continue; // 跳过当前行
        }
        executeCommand(line);
    }
}
bool Shell::isControlStatement(const std::string &command) {
    // 定义控制流语句和函数的列表
    static const std::set<std::string> controlStatements = {
        "if", "while", "for", "function"
    };
    return controlStatements.find(command) != controlStatements.end();
}

// 分词函数
std::vector<std::string> Shell::tokenize(const std::string& line) {
    std::vector<std::string> tokens;
    std::string token;
    size_t i = 0;
    while (i < line.length()) {
        char ch = line[i];
        if (isspace(ch)) {
            if (!token.empty()) {
                tokens.push_back(token);
                token.clear();
            }
        } else if (ch == '"' || ch == '\'') {
            // 处理引号内的字符串
            char quote = ch;
            while (++i < line.length()) {
                if (line[i] == quote) {
                    break; // 找到匹配的引号
                }
                token += line[i];
            }
            tokens.push_back(token);
            token.clear();
            ++i; // 跳过结束引号
        } else {
            token += ch;
        }
        ++i;
    }
    if (!token.empty()) {
        tokens.push_back(token);
    }
    return tokens;
}

void Shell::executeIf(const std::vector<std::string>& tokens) {
    // Join tokens back into a string
    std::string line = "";
    for (const auto& token : tokens)
        line += token + " ";

    // Find positions of keywords in the if statement
    size_t pos_if = line.find("if ");
    size_t pos_then = line.find("; then ");
    size_t pos_else = line.find("; else ");
    size_t pos_fi = line.find("; fi");

    if (pos_if == std::string::npos || pos_then == std::string::npos || pos_fi == std::string::npos) {
        std::cerr << "Syntax error in if statement" << std::endl;
        return;
    }

    // Extract condition, then part, and else part
    std::string condition = line.substr(pos_if + 3, pos_then - (pos_if + 3));
    std::string thenPart = line.substr(pos_then + 6, pos_else - (pos_then + 6));
    std::string elsePart = pos_else != std::string::npos ? line.substr(pos_else + 6, pos_fi - (pos_else + 6)) : "";

    // Tokenize condition, then part, and else part
    std::vector<std::string> conditionTokens = tokenize(condition);
    std::vector<std::string> thenTokens = tokenize(thenPart);
    std::vector<std::string> elseTokens = tokenize(elsePart);

    pid_t pid = fork();
    if (pid == 0) {
        executeSimpleCommand(conditionTokens);
        // 子进程中直接退出，不需要检查状态
        _exit(0); // 或者根据条件命令的成功与否使用适当的退出状态码
    } else if (pid > 0) {
        int status;
        // 父进程等待子进程结束，并获取退出状态
        waitpid(pid, &status, 0);
        // 检查子进程是否正常退出，并获取退出状态码
        if (WIFEXITED(status)) {
            int exitStatus = WEXITSTATUS(status);
            if (exitStatus == 0) {
                // 条件为真，执行 then 分支
                executeSimpleCommand(thenTokens);
            } else {
                // 条件为假，执行 else 分支（如果存在）
                if (!elsePart.empty()) {
                    executeSimpleCommand(elseTokens);
                }
            }
        } else {
            // 子进程没有正常退出
            perror("Child process did not terminate normally");
        }
    } else {
        // fork 失败
        perror("fork");
        exit(1);
    }
}

bool Shell::evaluateCondition(const std::vector<std::string>& conditionTokens) {
    // 将条件令牌合并成一个字符串
    std::string condition;
    for (const auto& token : conditionTokens) {
        condition += token + " ";
    }

    // 使用 system 函数执行条件命令，并检查返回值
    int result = system(condition.c_str());

    // 返回指示条件是否为真的布尔值
    return (result == 0);
}

void Shell::executeWhile(const std::vector<std::string>& tokens) {
    // 将 tokens 合并成一个字符串
    std::string line;
    for (const auto& token : tokens) {
        line += token + " ";
    }

    // 寻找 while 语句中关键字的位置
    size_t pos_while = line.find("while ");
    size_t pos_do = line.find("; do ");
    size_t pos_done = line.find("; done");

    if (pos_while == std::string::npos || pos_do == std::string::npos || pos_done == std::string::npos) {
        std::cerr << "while 语句语法错误" << std::endl;
        return;
    }

    // 提取条件和命令部分
    std::string condition = line.substr(pos_while + 6, pos_do - (pos_while + 6));
    std::string commands = line.substr(pos_do + 5, pos_done - (pos_do + 5));

    // 对条件和命令进行分词
    std::vector<std::string> conditionTokens = tokenize(condition);
    std::vector<std::string> commandTokens = tokenize(commands);

    // 执行 while 循环
    while (evaluateCondition(conditionTokens)) {
        executeSimpleCommand(commandTokens);
    }
}

void Shell::executeFunction(const std::vector<std::string>& tokens) {
    if (tokens.size() < 2) {
        std::cerr << "Invalid function definition" << std::endl;
        return;
    }

    std::string functionName = tokens[1];
    std::vector<std::string> functionBody;

    std::string line;
    while (std::getline(std::cin, line)) {
        // 假设函数定义以 "end" 作为结束标志
        if (line == "end") {
            break;
        }
        functionBody.push_back(line);
    }

    functions[functionName] = functionBody;
}


// 执行命令
void Shell::executeCommand(const std::string &line) {
    // 首先替换行中的变量
    std::string processedLine = replaceVariables(line);

    // 然后分词
    auto tokens = tokenize(processedLine);

    if (tokens.empty()) return;

    // 检查是否是控制流语句或函数
    if (isControlStatement(tokens[0])) {
        // 是控制流语句或函数，根据语句类型分别处理
        if (tokens[0] == "if") {
            executeIf(tokens);
        } else if (tokens[0] == "while") {
            executeWhile(tokens);
        } else if (tokens[0] == "for") {
            executeFor(tokens);
        } else if (tokens[0] == "function") {
            executeFunction(tokens);
        } else {
            std::cerr << "Unknown command: " << tokens[0] << std::endl;
        }
    } else {
        auto it = functions.find(tokens[0]);
        if (it != functions.end()) {
            // 是一个用户定义的函数
            for (const auto& cmd : it->second) {
                executeCommand(cmd); // 递归调用 executeCommand 执行函数体
            }
        } else {
            size_t pipe_pos = processedLine.find('|');
            if (pipe_pos != std::string::npos) {
                executeWithPipe(tokens, pipe_pos);
            } else {
                executeSimpleCommand(tokens);
            }
        }
    }
}



// 执行简单命令
void Shell::executeSimpleCommand(const std::vector<std::string>& tokens) {
     bool input_redirect = false, output_redirect = false, append_redirect = false;
        std::string input_file, output_file;
        std::vector<char*> args;

        prepareArgsAndRedirects(tokens, args, input_redirect, input_file, output_redirect, append_redirect, output_file);

        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(1);
        }

        if (pid == 0) { // Child process
            performRedirects(input_redirect, input_file, output_redirect, append_redirect, output_file);
            executeCommandWithArgs(args);
            _exit(1); // Use _exit to avoid flushing stdio buffers
        } else { // Parent process
            int status;
            waitpid(pid, &status, 0);
            if (WIFEXITED(status)) {
                std::cout << "Command exited with status " << WEXITSTATUS(status) << std::endl;
            }
        }
}

std::string Shell::replaceVariables(const std::string& line) {
    std::string result = line;
    // 简单的变量替换实现
    size_t startPos = 0;
    while ((startPos = result.find("${", startPos)) != std::string::npos) {
        size_t endPos = result.find('}', startPos);
        if (endPos == std::string::npos) break;
        std::string varName = result.substr(startPos + 2, endPos - startPos - 2);
        auto it = environment.find(varName);
        if (it != environment.end()) {
            result.replace(startPos, endPos - startPos + 1, it->second);
        }
        startPos += it->second.length();
    }
    return result;
}



// 通过管道执行命令
void Shell::executeWithPipe(const std::vector<std::string>& tokens, size_t pipe_pos) {
    std::vector<char*> args1, args2;
    std::vector<std::string> command1(tokens.begin(), tokens.begin() + pipe_pos);
    std::vector<std::string> command2(tokens.begin() + pipe_pos + 1, tokens.end());

    // 创建管道
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(1);
    }

    // 分叉第一个子进程
    pid_t pid1 = fork();
    if (pid1 == -1) {
        perror("fork");
        exit(1);
    }

    if (pid1 == 0) { // 第一个子进程
        // 关闭管道的读端
        close(pipefd[0]); // 不再需要读端

        // 将标准输出重定向到管道写端
        dup2(pipefd[1], STDOUT_FILENO);

        // 准备第一个命令的参数
        for (const auto& token : command1) {
            args1.push_back(const_cast<char*>(token.c_str()));
        }
        args1.push_back(nullptr); // 参数列表以空指针结束

        // 执行第一个命令
        executeCommandWithArgs(args1);
        _exit(1); // 执行完毕退出子进程
    } else {
        // 父进程或第二个子进程

        // 分叉第二个子进程
        pid_t pid2 = fork();
        if (pid2 == -1) {
            perror("fork");
            exit(1);
        }

        if (pid2 == 0) { // 第二个子进程
            // 关闭管道的写端
            close(pipefd[1]); // 不再需要写端

            // 将标准输入重定向到管道读端
            dup2(pipefd[0], STDIN_FILENO);

            // 准备第二个命令的参数
            for (const auto& token : command2) {
                args2.push_back(const_cast<char*>(token.c_str()));
            }
            args2.push_back(nullptr); // 参数列表以空指针结束

            // 执行第二个命令
            executeCommandWithArgs(args2);
            _exit(1); // 执行完毕退出子进程
        } else {
            // 父进程等待两个子进程结束
            close(pipefd[0]); // 父进程不需要管道
            close(pipefd[1]);

            int status;
            waitpid(pid1, &status, 0);
            waitpid(pid2, &status, 0);
        }
    }
}
// 准备参数和重定向
void Shell::prepareArgsAndRedirects(const std::vector<std::string>& tokens,
                                      std::vector<char*>& args,
                                      bool& input_redirect, std::string& input_file,
                                      bool& output_redirect, bool& append_redirect, std::string& output_file) {
   input_redirect = output_redirect = append_redirect = false;
        size_t i = 0;
        while (i < tokens.size()) {
            if (tokens[i] == "<") {
                i++;
                input_redirect = true;
                input_file = (i < tokens.size()) ? tokens[i] : "";
            } else if (tokens[i] == ">") {
                i++;
                output_redirect = true;
                output_file = (i < tokens.size()) ? tokens[i] : "";
                if (i + 1 < tokens.size() && tokens[i + 1] == ">>") {
                    append_redirect = true;
                    i++;
                }
            } else {
                args.push_back(const_cast<char*>(tokens[i].c_str()));
            }
            ++i;
        }
        args.push_back(nullptr); // Null-terminated argument list
}

// 执行重定向
void Shell::performRedirects(bool input_redirect, const std::string& input_file,
                              bool output_redirect, bool append_redirect, const std::string& output_file) {
    if (input_redirect) {
            int fd = open(input_file.c_str(), O_RDONLY);
            if (fd == -1) {
                perror("open input file");
                exit(1);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }

        if (output_redirect) {
            int flags = O_WRONLY | O_CREAT;
            if (append_redirect) {
                flags |= O_APPEND;
            } else {
                flags |= O_TRUNC;
            }
            int fd = open(output_file.c_str(), flags, 0644);
            if (fd == -1) {
                perror("open output file");
                exit(1);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
        }
}

// 执行命令与参数
void Shell::executeCommandWithArgs(std::vector<char*>& args) {
    // 检查参数列表是否为空
    if (args.empty() || args[0] == nullptr) {
        std::cerr << "Error: No command to execute" << std::endl;
        _exit(1);
    }

    // 执行命令
    if (execvp(args[0], args.data()) == -1) {
        perror("execvp");
        std::cerr << "Error executing command: " << args[0] << std::endl;
        _exit(1);
    }
}
void Shell::executeFor(const std::vector<std::string>& tokens) {
    if (tokens.size() < 4 || tokens[1] != "in") {
        std::cerr << "Syntax error in for loop" << std::endl;
        return;
    }

    // 假设 for 循环的格式为：for var in list; do ... done
    std::string varName = tokens[0];   // 循环变量名
    std::vector<std::string> list = tokenize(tokens[2]); // 列表项，需要分割

    // 循环体，这里假设所有剩余的 tokens 构成循环体
    std::vector<std::string> body(tokens.begin() + 3, tokens.end());

    for (const auto& item : list) {
        // 在每次迭代前，将循环变量设置为列表中的当前项
        environment[varName] = item;

        // 执行循环体中的命令
        for (const auto& cmd : body) {
            executeCommand(cmd);
        }
    }

    // 循环结束后，最好从环境中移除循环变量，除非需要保留其最终值
    environment.erase(varName);
}




// 主函数
int main() {
    Shell shell;
    shell.run();
    return 0;
}
